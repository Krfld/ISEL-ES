import '../modules/firebase.dart';

import '../.imports.dart';

class Data {
  static String? currentGroupId;
  static String? currentListId;
}
