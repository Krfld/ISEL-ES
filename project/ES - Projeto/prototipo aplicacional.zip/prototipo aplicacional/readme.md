Para testar o protótipo aplicacional é possível usar o ficheiro apk já criado.
Basta instalar o aplicativo num dispositivo Android ou num emulador.

Para poder correr o código do protótipo aplicacional, é necessário fazer download do SDK do Flutter
Aconselha-se a usar o VScode e instalar a extensão do Flutter (que instala também a linguagem Dart)

Para correr, é preciso ligar um dispositivo Android ao PC e correr o projeto.
Se for preciso usar um emulador Android, é preciso instalar o Android Studio e criar um dispositivo.
Desta forma o projeto será lançado em modo debug, ao contário de ao usar o apk que lança em modo release.